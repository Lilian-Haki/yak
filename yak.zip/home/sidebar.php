<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0;background:#0f0;">
            <div class="navbar-header" style="background:#E14C07;">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index" style="background:#E14C07;">YAK Admin</a>
            </div>
            <div align="center"><h3><strong><b>YOUTH ALIVE KENYA ~ YAK</b></strong></h3></div>
        </nav>
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <a class="" href="index" style="background:#0f0;color:#000;"><i class="fa fa-dashboard "></i>Dashboard</a>
                    </li>
					<li>
                        <a href="#"><i class="fa fa-power-off fa-fw"></i>My Profile</a>
                            <ul class="nav nav-second-level">
                                <li>
                                <a href="#"data-toggle="modal" data-target="#ModalA">
                                <button class="btn btn-success">
                        <span>Profile</span></button></a>
                                </li>
                                <li>
                                <a href="logout"
                      onclick="return confirm('Click Ok to LogOut.');">
                      <button class="btn btn-danger" type="button">
                        <span>LogOut</span></button></a>
                               </li>
                               </ul>
                            </li>
					<li>
                        <a href="#"><i class="fa fa-times fa-fw"></i>Settings</a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="sets">Password Resets</a>
                                </li>
                               </ul>
			                   <li>
                     <li>
                         <a href="#"><i class="fa fa-apple fa-fw"></i>Application</a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="appeve">Events</a>
                                </li>
                                <li>
                                    <a href="apppres">Presentation Requests</a>
                                </li>
                                <li>
                                    <a href="apptick">Tickets</a>
                                </li>
                                <li>
                                    <a href="appspon">Sponsorship</a>
                                </li>
                                <li>
                                    <a href="appbook">Bookings</a>
                                </li>
                                <li>
                                    <a href="appbkpy">Booking Payments</a>
                                </li>
                                <li>
                                    <a href="appallpy">All Payments</a>
                                </li>
                                <li>
                                    <a href="appnoti">Notices</a>
                                </li>
                                <li>
                                    <a href="appfeed">Feedback</a>
                                </li>
                                <li>
                                    <a href="appmone">Book Record</a>
                                </li>
                               </ul>
                    </li>
					<li>
                        <a href="#"><i class="fa fa-group fa-fw"></i>Clients</a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="clin">New Clients</a>
                                </li>
                                <li>
                                    <a href="clip">Approved Clients</a>
                               </li>
                                <li>
                                    <a href="clix">Rejected Clients</a>
                        
                               </li>
                               </ul>
			                   <li>
                
                         <a href="#"><i class="fa fa-money fa-fw"></i>Partners</a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="parn">New Partners</a>
                                </li>
                                <li>
                                    <a href="parp">Approved Partners </a>
                               </li>
                                <li>
                                    <a href="parx">Rejected Partners</a>
                        
                               </li>
                               </ul>
                               </li>	
                                       <li>
                            <a href="#"><i class="fa fa-star fa-fw"></i>Mentors</a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="menn">New Mentors</a>
                                </li>
                                <li>
                                    <a href="menp">Approved Mentors</a>
                               </li>
                                <li>
                                    <a href="menx">Rejected Mentors</a>
                        
                               </li>
                               </ul>
                                    </li>	    
<li>
                        
                         <a href="#"><i class="fa fa-certificate fa-fw"></i>Trainers</a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="tran">New Trainers</a>
                                </li>
                                <li>
                                    <a href="trap">Approved Trainers</a>
                               </li>
                                <li>
                                    <a href="trax">Rejected Trainers</a>
                        
                               </li>
                               </ul>
                    </li>
                     <li>
                         <a href="#"><i class="fa fa-dollar fa-fw"></i>Finance Managers</a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="finn">New Managers</a>
                                </li>
                                <li>
                                    <a href="finp">Approved Managers</a>
                               </li>
                                <li>
                                    <a href="finx">Rejected Managers</a>
                        
                               </li>
                               </ul>
                    </li>
                    <li>
                         <a href="#"><i class="fa fa-table fa-fw"></i>Event Managers</a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="even">New Managers</a>
                                </li>
                                <li>
                                    <a href="evep">Approved Managers</a>
                               </li>
                                <li>
                                    <a href="evex">Rejected Managers</a>
                               </li>
                               </ul>
                    </li>
                    <li>
                         <a href="#"><i class="fa fa-wrench fa-fw"></i>Service Managers</a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="sern">New Managers</a>
                                </li>
                                <li>
                                    <a href="serp">Approved Managers</a>
                               </li>
                                <li>
                                    <a href="serx">Rejected Managers</a>
                               </li>
                               </ul>
                    </li>
                </ul>
            </div>
        </nav>
        <div id="ModalA" class="modal fade" role="dialog">
            <div class="modal-dialog modal-sm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">My Profile</h4>
                    </div>
                    <div class="modal-body">
                        <form method="post" autocomplete="off">
                            <?php $profile=mysqli_fetch_assoc(mysqli_query($conn,"select * from admin where admno='".$_SESSION['YAK']."'"));?>
                            RegNo:&nbsp;<span><?php echo $profile['admno'];?></span><br>
                            Firstname:&nbsp;<span><?php echo $profile['fname'];?></span><br>
                            Lastname:&nbsp;<span><?php echo $profile['lname'];?></span><br>
                            Email:&nbsp;<span><?php echo $profile['email'];?></span><br>
                            RegDate:&nbsp;<span><?php echo $profile['date'];?></span>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>