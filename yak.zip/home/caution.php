<?php
ob_start();
error_reporting(0);
session_start();
include("data/conn.php");?>